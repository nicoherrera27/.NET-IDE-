﻿namespace Console {
    class Program {
        static void Main(string[] args) {
            System.Console.WriteALine("Esta linea va a dar error!");
        }
    }
}
